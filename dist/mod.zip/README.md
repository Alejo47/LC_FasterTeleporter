# Faster Teleporter

Simple mod that removes the cooldown on the inverse teleporter for either big
groups or people who like chaos, or both
